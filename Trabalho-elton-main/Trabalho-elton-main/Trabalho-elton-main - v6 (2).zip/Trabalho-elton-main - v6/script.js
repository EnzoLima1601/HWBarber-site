document.addEventListener("DOMContentLoaded", function () {
  TrocaParaPagAgendamento();
  header();
});

//Header
function header() {
  var Inicio = document.getElementById("botaoInicio");
  if (Inicio) {
    Inicio.addEventListener("click", function () {
      window.location.href = "../TelaInicio/TelaInicio.html";
    });
  }
  var Cortes = document.getElementById("botaoCortes");
  if (Cortes) {
    Cortes.addEventListener("click", function () {
      window.location.href = "../Servicos/servico1.html";
    });
  }
}

//Tela Inicio
function TrocaParaPagAgendamento() {
  var Trocapag = document.getElementById("TrocaPagina1");
  if (Trocapag) {
    Trocapag.addEventListener("click", function () {
      window.location.href = "../Tela Agendamento/TelaAgendamento.html";
    });
  }
  var Trocapag2 = document.getElementById("TrocaPagina2");
  if (Trocapag2) {
    Trocapag2.addEventListener("click", function () {
      window.location.href = "../Tela Agendamento/TelaAgendamento.html";
    });
  }
  var Trocapag3 = document.getElementById("TrocaPagina3");
  if (Trocapag3) {
    Trocapag3.addEventListener("click", function () {
      window.location.href = "../Tela Agendamento/TelaAgendamento.html";
    });
  }
}
//Fim Tela Inicio
